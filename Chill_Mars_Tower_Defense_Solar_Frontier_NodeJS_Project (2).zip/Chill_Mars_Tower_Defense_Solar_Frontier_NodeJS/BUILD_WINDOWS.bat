@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo   CHILL MARS TOWER DEFENSE - NODE.JS BUILDER
echo ===============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not on PATH.
  echo Install Node.js 20 or newer from https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js with npm included.
  pause
  exit /b 1
)
echo [1/2] Installing Node.js project dependencies...
call npm install
if errorlevel 1 (
  echo ERROR: npm install failed.
  pause
  exit /b 1
)
echo.
echo [2/2] Building the 64-bit Windows installer...
call npm run build:win
if errorlevel 1 (
  echo ERROR: Windows packaging failed.
  pause
  exit /b 1
)
echo.
echo SUCCESS. Check the dist folder for the installer.
pause
