'use strict';

const { app, BrowserWindow, Menu, protocol } = require('electron');
const path = require('node:path');
const { getGameDocument } = require('./renderer');

// Register a secure, standard app origin before Electron becomes ready.
// This keeps browser storage (saved progress/settings) available without shipping
// a separate HTML file in the project.
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'chillmars',
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true
    }
  }
]);

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 650,
    show: false,
    backgroundColor: '#071018',
    autoHideMenuBar: true,
    title: 'Chill Mars Tower Defense',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.setMenuBarVisibility(false);
  win.loadURL('chillmars://game/index');
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(() => {
  protocol.handle('chillmars', () => new Response(getGameDocument(), {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store'
    }
  }));

  Menu.setApplicationMenu(null);
  app.setAppUserModelId('com.cmtdofficial.chillmarstowerdefense');
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
