# Chill Mars Tower Defense — Solar Frontier Update v1.3.2

A Node.js + Electron Windows project. The game view is compressed and embedded inside `renderer.js`, so the project does **not** contain or require a separate `.html` file.

## Run the game

1. Install Node.js 20 or newer from <https://nodejs.org/>.
2. Extract this ZIP to a folder.
3. Open a terminal in that folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

## Build a Windows installer

On Windows, double-click `BUILD_WINDOWS.bat`, or run:

```bash
npm install
npm run build:win
```

The installer will be created in `dist/`. This ZIP is the source project; it is not a prebuilt `.exe` installer.

## Project files

- `main.js` — Electron main process and secure app window.
- `renderer.js` — compressed, embedded game renderer payload.
- `package.json` — Node.js dependencies and Electron Builder configuration.
- `BUILD_WINDOWS.bat` — Windows installer build helper.
- `UPDATE_NOTES.md` — Solar Frontier update notes.

## Notes

- `node_modules/` and `dist/` are intentionally excluded from the source ZIP.
- Player account/leaderboard networking still requires the backend configuration described in the account setup notes from the prior project; this update does not provision a live backend.

## Auto Waves
During a match, press **AUTO WAVES: OFF** to enable automatic wave launching. You still launch wave 1 manually after setting up defenses. After each cleared wave, the next wave starts after a 4-second setup break. The countdown pauses with the game, uses real seconds (not accelerated game time), and stops at the final campaign wave or when the match ends. Turning Auto Waves off cancels a pending countdown. Your Auto Waves preference is saved locally.
