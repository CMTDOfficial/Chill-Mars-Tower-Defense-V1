# Solar Frontier Update — v1.3.0

## New destinations

- **Earth City:** a green urban district with buildings, windows, roads, grass, park details, trees, and animated pedestrian residents running along designated sidewalks and park lanes.
- **Moon — Mare Tranquillitatis:** a lunar landscape with craters, stars, an Earth-in-the-sky view, lunar habitat structures, and a chance of astronaut visitors.
- **Moon — Shackleton Crater:** a second, visually distinct lunar outpost with shadowed polar terrain, craters, rocks, habitat structures, and a chance of astronaut visitors.

## Lunar visitors

Each new lunar mission rolls a 20% chance to spawn a visitor group. When the roll succeeds, exactly three small astronauts appear and walk around the map. They are environmental visitors and do not affect combat or tower placement.

## Gameplay interface

- Removed the small badge/achievement strip from the lower-left gameplay sidebar.
- The selected-tower panel now occupies that space and presents the existing **Upgrade** and **Sell** actions.
- The full badge collection remains accessible through the game's badge page/menu.

## RGB Chromatic drop

Defeating a Witty Alien now has an independent **1-in-100 (1%)** chance to award the RGB Chromatic color. The RGB Chromatic badge is awarded with the unlock. Existing crate drop odds are unchanged.

## Compatibility

Existing Mars maps, progression, tower systems, saves, and other crate odds are retained. The map selection and mission setup include all new locations.

## Verification note

The project JavaScript and embedded game script were syntax-checked. Automated browser checks exercised map selection, Earth City deployment, the Witty Alien RGB reward path, and the successful three-astronaut spawn path. A complete manual playthrough on a Windows PC is still recommended.


## Update v1.3.1 — Auto Waves
- Added an Auto Waves toggle beside Launch Wave.
- When enabled, the first wave or the next wave starts after a 4-second preparation break.
- Countdown pauses while the match is paused and stops at campaign completion or game over.
- Auto Waves preference is remembered locally between sessions.
- Manual wave launch cancels the pending countdown.
## v1.3.2 — Auto Waves
- Added a clearly highlighted AUTO WAVES toggle to the in-match control row. Its ON/OFF state is saved between sessions.
- The player manually launches wave 1 after setting up defenses; subsequent waves start automatically 4 seconds after the previous wave is cleared.
- Countdown pauses with the game and uses real seconds, regardless of 1×, 1.5×, or 2× gameplay speed.
- Turning Auto Waves off cancels any pending countdown immediately. Campaign completion stops automatic launching; Endless mode continues until defeat.
- Continuing a saved run with Auto Waves enabled schedules the next wave after a 4-second preparation break.
